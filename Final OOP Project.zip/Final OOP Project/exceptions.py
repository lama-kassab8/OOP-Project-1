class ItemNotFoundError(Exception):
    pass

class UserNotFoundError(Exception):
    pass

class ItemAlreadyBorrowed(Exception):
    pass

class ItemNotBorrowed(Exception):
    pass

class ItemAlreadyReserved(Exception):
    pass


