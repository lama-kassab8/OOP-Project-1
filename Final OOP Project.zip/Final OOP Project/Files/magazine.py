from abc import ABC, abstractmethod
from library_item import LibraryItem
from reservable import Reservable

class Magazine(LibraryItem, Reservable):
    #This class inherits from two parents: LibraryItem class and Reservable class

    def __init__(self, title, author, is_available, genre):
        super().__init__(title, author, is_available)
        self.genre= genre

    def display_info(self):
        print(f"Title: {self.title}, author: {self.author}")
    
    def check_availability(self):
        return self.is_available