from abc import ABC, abstractmethod

class Reservable(ABC):

    @abstractmethod
    def borrow(self):
        pass

    @abstractmethod
    def return_item(self):
        pass
