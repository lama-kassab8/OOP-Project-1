class User:

    def __init__(self, user_id, name, borrowed_items=None):
        #Each user has a nmae and ID
        self.user_id= user_id
        self.name= name
        #This part creates an empty list if the user hasn't borrowed any books yet.
        self.borrowed_items= borrowed_items if borrowed_items is not None else []