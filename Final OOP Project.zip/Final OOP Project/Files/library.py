import json
from library_item import LibraryItem
from user import User
from clean import Clean
from exceptions import ItemNotFoundError, ItemNotBorrowed, ItemAlreadyBorrowed, UserNotFoundError

class Library:
        def __init__(self,users=None, items= None ):
            #First, I initialize the library with two lists: users and items.
            self.users= users if users is not None else[]
            self.items= items if items is not None else[]


        def add_item(self, item):
            #I load the existing items from the JSON file.
            try:
                with open("items.json", "r") as f:
                    items=json.load(f)
            except(FileNotFoundError, json.JSONDecodeError) as e:
                print(f"{e}: No items found. Starting anew!")
                items= []
            #I use isinstance to verify that the item that's about to be added is an instance of the LibraryItem class.
            if isinstance(item, LibraryItem):
                formatted_title= Clean.format_title(item.title) #This part formats the title before adding it using my custom-made format in the Clean class.
                try:
                    items.append({
                        'title':formatted_title.title,
                        'author':item.author,
                        'is_available': item.is_available
                    })
                except Exception as e:
                    print(f"Error while adding item: {e}")
                finally: #I use "finally" to always save the file at the end.
                    try:
                        # This segment saves the updated list back to JSON.
                        with open("items.json", "w") as f:
                            json.dump(items, f, indent= 4)
                    except IOError as e:
                        print(f"Error while saving items: {e}")
                    print("A new item has been added.")
            else:
                print("You can only to add LibraryItem instances.")
        

        def remove_item(self):
            #First, I ask the user for the item that they want to remove.
            removed= input("What's the item that you want to remove?")
            try:
                with open("items.json", "r") as f:
                    items= json.load(f)
            except(FileNotFoundError, json.JSONDecodeError) as e:
                print(f"{e}: No items found. Starting anew!")
                items= []
            # This segment filters out the item that needs to be removed.
            updated_items = []
            for item in items:
                if item["title"] != removed:
                    updated_items.append(item)
            try:
                pass
                
            finally:  # I use "finally" to always save the updated list.
                try:
                    with open("items.json", "w") as f:
                        json.dump(updated_items,f, indent=4)
                        print(f"{removed} is now removed from the library.")
                except IOError as e:
                    print(f"Error while saving items: {e}")
            

        def add_users(self, user):
            #I first need to load the existing users from the JSON file.
            try:
                with open("users.json", "r") as f:
                    users= json.load(f)
            except(FileNotFoundError, json.JSONDecodeError) as e:
                print(f"{e}: No users found. Starting anew!")
                users=[]
            # I make sure that the user being added is an instance of the class User.
            if isinstance(user, User):
                users.append({
                    'Name': user.name,
                    'Id': user.user_id,
                    'Borrowed Items': user.borrowed_items
                })
                try:
                    pass
                finally:
                    #I save the updated list.
                    try:
                        with open("users.json", "w") as f:
                            json.dump(users, f, indent=4)
                            print("A new user has joined the library.")
                    except IOError as e:
                        print(f"Error while saving users: {e}")
            else:
                print("You can only add User instances.")
        
        
        def remove_users(self):
            #I ask the user for ID to remove the user instead of using the user's name just in case there are repeated names in the list since IDs are always unique.
            remove_user=int(input("What's the ID of the user you want to remove? "))
            try:
                with open ("users.json", "r") as f:
                    users=json.load(f)
            except (FileNotFoundError, json.JSONDecodeError, UserNotFoundError) as e:
                print(f"{e}: No users found. Starting anew!")
                users=[]
            #This segment filters out the user that needs to be removed.
            updated_users=[]
            for user in users:
                if user["Id"] != remove_user:
                    updated_users.append(user)
            try:
                pass
            finally:
                # I then save the updated list.
                try:
                    with open("users.json", "w") as f:
                        json.dump(updated_users, f, indent=4)
                        print(f"{remove_user} is now removed from the data hub of users.")
                except IOError as e:
                    print(f"Error while saving users: {e}")


                
        def borrow_item(self):
            #I ask the user to input the title that they want to borrow
            to_borrow=input("What the title of the item you want to borrow? ").lower()
            try:
                with open("items.json", "r") as f:
                    items= json.load(f)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                    print(f"{e}: No items found.")
                    return
            found= False #I assume that the item hasn't been found yet.
            for item in items:
                if item["title"].lower()==to_borrow:
                    if item["is_available"]:
                        item["is_available"] = False # I set is_available to False to indicate that it's no longer available for borrowing because it has just gotten borrowed.
                        print(f"You've just borrowed {item['title']}!")
                    else:
                        raise ItemAlreadyBorrowed(f"Sorry! Someone else has borrowed {item['title']}.")
                    break
            else:
                raise ItemNotFoundError("Item not found.")
            #This part saves the updated changes so the item's status is updated.
            with open("items.json", "w") as f:
                json.dump(items, f, indent=4)
                


        def return_item(self):
            #I ask the user of the item they want to return.
            to_return=input("What the title of the item you want to return? ").lower()
            try:
                with open("items.json", "r") as f:
                    items= json.load(f)
            except (FileNotFoundError, json.JSONDecodeError)as e:
                    print(f"{e}: No items found.")
                    return
            found= False #I assume that the item hasn't been found yet.
            for item in items:
                if item["title"].lower()==to_return:
                    if item["is_available"]:
                        item["is_available"] = True #I set it back to True to indicate that now the item is available for borrowing again.
                        print(f"You've just returned {item['title']}!")
                    else:
                        raise ItemNotBorrowed(f"{item['title']} was never borrowed to begin with.")
                    break
            else:
                raise ItemNotFoundError("Item not found.")
            #This part saves the updated changes so the item's status is updated.
            with open("items.json", "w") as f:
                json.dump(items, f, indent=4)
                
        

        def view_items(self):
            try:
                with open("items.json", "r") as f:
                    items = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"{e}: No items to display.")
                return
            if not items:
                print("No items found in the library.")
                return
            print("Here's a list of all the items:\n")
            for item in items:
                status = "Available" if item["is_available"] else "Not Available"
                print(f"- {item['title']} by {item['author']} ({status})")
    




