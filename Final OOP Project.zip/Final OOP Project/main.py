import json
from Files.library import Library
from Files.user import User
from Files.reservable import Reservable
from Files.library_item import LibraryItem
from Files.book import Book
from Files.dvd import DVD
from Files.magazine import Magazine
from exceptions import ItemNotFoundError, ItemAlreadyReserved

#I create an instance of the class Library to manage users and items.
library= Library()

print("Welcome to the Library System!")
while True: #I use this loop to keep showing the menu until the user exits.
    try:
        option= int(input("Type the number of the option you want:\n 1. View all available items\n 2. Search item by title or type\n 3. Register as a new user\n 4. Borrow an item\n 5. Reserve an item\n 6. Return an item\n 7.Exit and save.\n"))
    except ValueError:
        print("Invalid input. Please enter a number between 1 and 7.")
        continue  # This part breaks out of the loop if the input isn't valid.

    if option not in [1, 2,3,4,5,6,7]:  # I check if the input is valid.
        print("Invalid option, please choose a number between 1 and 7.")
        continue  # This part skips the rest of the loop and asks for input again.
    

    if option == 1:
        library.view_items() #I use the view_items function in the Library class to display all items in the JSON file.


    elif option ==2:
        search= input("What's the tite or type of the item you want to search for: \n")
        found= False
        for item in library.items:
            if search in item['title'].lower() or search in item['type'].lower():
                found= True
                status= "Available" if item['is_available'] else "Unavailable" #This means if item['is_available] is True, mark it as available, else mark it unavailable
                print(f"-{item['title']} by {item['author']} {status}")
        if not found:
            raise ItemNotFoundError("Sorry! No items found matching your search.")


    elif option==3:
        name= input("Enter the name of the user: ")
        import random
        user_id= random.randint(1000, 5555) # I use the random library to generate random IDs for the registered users.
        new_user=User(user_id, name)
        library.add_users(new_user)
        print(f"{name} is now a library member, registered with ID: {user_id}.")


    elif option==4:
        library.borrow_item() #This calls the borrow_item function in the class Library.


    elif option==5:
        try:
            reserve_item= input("What's the title of the item you want to reserve? ")
            for item in library.items:
                if reserve_item==item.title.lower():
                    if isinstance(item,DVD) or isinstance(item, Book): #I use isinstance to state that only items in the DVD class and Book class can be reserved.
                        if not item.is_available and not item.is_reserved:# Here, I check if the item is available and not reserved.
                            item.is_reserved=True
                            print(f"{item.title} has been reserved.")
                        else:
                            raise ItemAlreadyReserved("Item is either available or already reserved.")
                    else:
                        print("Unfortunately, only DVDs and books can be reserved.")
                    break
            else:
                raise ItemNotFoundError("Item isn't found.")
        
        finally:
            # I use "finally" to always save changes whether an error occurred or didn't.
            with open("items.json", "w") as f:
                json.dump(library.items, f, indent=4)

    elif option==6:
        library.return_item() #This also called the return_item fuction in the Library class.


    elif option == 7:
        #This option saves all the changes made by the user and updates the lists accordingly before exiting the program.
        print("Thank you for using our Library System. Saving data and exiting...")
        with open("items.json", "w") as f:
            json.dump(library.items, f, indent=4)
        with open("users.json", "w") as f:
            json.dump(library.users, f, indent=4)


    break  #This breaks out of the loop and ends the program.
